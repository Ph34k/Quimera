
import React, { useState, useCallback } from 'react';
import { Handoff } from '../types';
import { suggestFirstMessage } from '../services/geminiService';
import { SparklesIcon } from './icons/Icons';

interface ConversationDetailModalProps {
  handoff: Handoff;
  onClose: () => void;
}

const ConversationDetailModal: React.FC<ConversationDetailModalProps> = ({ handoff, onClose }) => {
  const [suggestedMessage, setSuggestedMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSuggestMessage = useCallback(async () => {
    setIsLoading(true);
    setError('');
    setSuggestedMessage('');
    try {
      const message = await suggestFirstMessage(handoff.profile, {
          initialMessage: handoff.lastMessage,
          response: "Oi! Adorei sua foto, que lugar incrível! E sim, amo fotografia também :)",
      });
      setSuggestedMessage(message);
    } catch (err) {
      setError('Failed to generate suggestion. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [handoff]);

  const { profile } = handoff;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50" onClick={onClose}>
      <div className="bg-dark-card rounded-lg shadow-2xl w-full max-w-2xl border border-dark-border m-4 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-bold text-white">Conversation Handoff</h2>
            <button onClick={onClose} className="text-dark-text-secondary hover:text-white">&times;</button>
          </div>
          
          <div className="flex items-center space-x-4 mb-6">
            <img src={profile.avatarUrl} alt={profile.name} className="w-20 h-20 rounded-full object-cover" />
            <div>
              <h3 className="text-xl font-bold text-white">{profile.name}, {profile.age}</h3>
              <p className="text-md text-dark-text-secondary">@{profile.username} &bull; {profile.location}</p>
            </div>
          </div>

          <div className="bg-dark-bg p-4 rounded-lg mb-4">
            <h4 className="font-semibold text-brand-light mb-2">Profile Bio</h4>
            <p className="text-sm text-dark-text italic">"{profile.bio}"</p>
            <h4 className="font-semibold text-brand-light mt-3 mb-2">Interests</h4>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map(interest => (
                <span key={interest} className="bg-dark-border text-xs px-2 py-1 rounded-full">{interest}</span>
              ))}
            </div>
          </div>

          <div className="bg-dark-bg p-4 rounded-lg mb-6">
            <h4 className="font-semibold text-brand-light mb-2">Conversation History</h4>
            <div className="text-sm space-y-2">
              <p><span className="font-semibold text-dark-text-secondary">System:</span> {handoff.lastMessage}</p>
              <p><span className="font-semibold text-white">{profile.name}:</span> Oi! Adorei sua foto, que lugar incrível! E sim, amo fotografia também :)</p>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-brand-light mb-2">Your Turn</h4>
            <div className="bg-dark-bg p-4 rounded-lg">
                <textarea className="w-full bg-transparent border-0 text-dark-text focus:ring-0 p-0" rows={4} placeholder="Write your message here..."></textarea>
                <div className="border-t border-dark-border mt-2 pt-2 flex justify-end">
                    <button 
                        onClick={handleSuggestMessage} 
                        disabled={isLoading}
                        className="flex items-center bg-brand-purple text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-brand-light disabled:bg-gray-500 transition-colors"
                    >
                        <SparklesIcon className="h-4 w-4 mr-2" />
                        {isLoading ? 'Generating...' : 'Suggest Reply with AI'}
                    </button>
                </div>
                {suggestedMessage && (
                    <div className="mt-4 p-3 bg-dark-border rounded-lg text-sm italic">
                        <p>{suggestedMessage}</p>
                    </div>
                )}
                {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
            </div>
            
          </div>

        </div>
      </div>
    </div>
  );
};

export default ConversationDetailModal;
