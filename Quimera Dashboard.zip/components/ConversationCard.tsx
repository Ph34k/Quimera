
import React from 'react';
import { Handoff } from '../types';

interface ConversationCardProps {
  handoff: Handoff;
  onSelect: () => void;
}

const ConversationCard: React.FC<ConversationCardProps> = ({ handoff, onSelect }) => {
  return (
    <div 
      onClick={onSelect}
      className="bg-dark-card p-4 rounded-lg shadow-lg border border-dark-border flex items-start space-x-4 cursor-pointer hover:bg-gray-700 transition-colors"
    >
      <img src={handoff.profile.avatarUrl} alt={handoff.profile.name} className="w-16 h-16 rounded-full object-cover" />
      <div className="flex-1">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">{handoff.profile.name} <span className="text-sm font-normal text-dark-text-secondary">@{handoff.profile.username}</span></h3>
          <span className="text-xs text-dark-text-secondary">{handoff.timestamp}</span>
        </div>
        <p className="text-sm text-dark-text mt-1 truncate">"{handoff.lastMessage}"</p>
        <div className="flex items-center justify-end text-sm mt-2">
            <span className="text-dark-text-secondary mr-2">Interest Score:</span>
            <span className="font-bold text-brand-light">{handoff.interestScore}</span>
        </div>
      </div>
    </div>
  );
};

export default ConversationCard;
