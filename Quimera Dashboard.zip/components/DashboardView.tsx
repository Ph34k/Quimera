
import React from 'react';
import MetricCard from './MetricCard';
import PerformanceChart from './PerformanceChart';
import { Metric } from '../types';

const mockMetrics: Metric[] = [
  { label: 'Profiles Analyzed (24h)', value: '874', change: '+15%', changeType: 'increase' },
  { label: 'Contacts Sent (24h)', value: '62', change: '+8%', changeType: 'increase' },
  { label: 'Response Rate', value: '28.4%', change: '-1.2%', changeType: 'decrease' },
  { label: 'Successful Handoffs', value: '11', change: '+2', changeType: 'increase' },
];

const DashboardView: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {mockMetrics.map(metric => <MetricCard key={metric.label} metric={metric} />)}
      </div>

      <div className="bg-dark-card p-6 rounded-lg shadow-lg border border-dark-border">
          <h2 className="text-xl font-semibold text-white mb-4">7-Day Performance</h2>
          <PerformanceChart />
      </div>
    </div>
  );
};

export default DashboardView;
