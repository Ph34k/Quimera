
import React from 'react';
import { Metric } from '../types';

interface MetricCardProps {
  metric: Metric;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  const changeColor = metric.changeType === 'increase' ? 'text-green-400' : 'text-red-400';

  return (
    <div className="bg-dark-card p-6 rounded-lg shadow-lg border border-dark-border">
      <h3 className="text-md text-dark-text-secondary mb-2">{metric.label}</h3>
      <div className="flex items-baseline justify-between">
        <p className="text-3xl font-bold text-white">{metric.value}</p>
        {metric.change && (
          <span className={`text-sm font-semibold ${changeColor}`}>
            {metric.change}
          </span>
        )}
      </div>
    </div>
  );
};

export default MetricCard;
