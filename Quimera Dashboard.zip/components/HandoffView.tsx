
import React, { useState } from 'react';
import { Handoff, Profile, Conversation } from '../types';
import ConversationCard from './ConversationCard';
import ConversationDetailModal from './ConversationDetailModal';

const mockHandoffs: Handoff[] = [
  {
    id: 'h1',
    profile: {
      id: 'p1', name: 'Juliana Silva', username: 'juli_silva', avatarUrl: 'https://picsum.photos/seed/p1/200', age: 28, bio: 'Amo viajar e conhecer lugares novos! ✈️ Fotografia e yoga nas horas vagas.', interests: ['viagem', 'fotografia', 'yoga'], personality: ['aventureira', 'criativa'], location: 'Varginha, MG', scores: { interesting: 8.5, attractive: 7.8, single: 9.0, final: 8.4 },
    },
    lastMessage: 'Oi, tudo bem? Vi que você também ama fotografia. Adorei sua foto em Machu Picchu!',
    timestamp: '2 hours ago',
    interestScore: 92,
  },
  {
    id: 'h2',
    profile: {
      id: 'p2', name: 'Carla Dias', username: 'carlad', avatarUrl: 'https://picsum.photos/seed/p2/200', age: 25, bio: 'Só uma garota que ama cachorros, pizza e um bom livro.', interests: ['cachorros', 'leitura', 'pizza'], personality: ['amigável', 'caseira'], location: 'Varginha, MG', scores: { interesting: 7.2, attractive: 8.1, single: 8.5, final: 7.9 },
    },
    lastMessage: 'Hey! Vi que temos vários amigos em comum. Que coincidência encontrar seu perfil!',
    timestamp: '5 hours ago',
    interestScore: 85,
  },
];

const HandoffView: React.FC = () => {
    const [selectedHandoff, setSelectedHandoff] = useState<Handoff | null>(null);

  const handleSelectHandoff = (handoff: Handoff) => {
    setSelectedHandoff(handoff);
  };

  const handleCloseModal = () => {
    setSelectedHandoff(null);
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-6">Handoffs</h1>
      <p className="text-dark-text-secondary mb-8">These conversations have shown high interest and are ready for you to take over.</p>
      
      <div className="space-y-4">
        {mockHandoffs.map(handoff => (
          <ConversationCard key={handoff.id} handoff={handoff} onSelect={() => handleSelectHandoff(handoff)} />
        ))}
      </div>

      {selectedHandoff && (
        <ConversationDetailModal 
            handoff={selectedHandoff}
            onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default HandoffView;
