import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Profile, Conversation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function suggestFirstMessage(profile: Profile, conversation: Conversation): Promise<string> {
    const prompt = `
      You are an expert in crafting engaging, authentic, and respectful opening messages for social interactions. Your name is Alex.
      
      Your task is to write a follow-up message to continue a conversation.
      
      Here is the context about the person you are talking to:
      - Name: ${profile.name}
      - Age: ${profile.age}
      - Bio: "${profile.bio}"
      - Interests: ${profile.interests.join(', ')}
      - Personality traits: ${profile.personality.join(', ')}

      Here is the conversation so far:
      - Your initial message: "${conversation.initialMessage}"
      - Their response: "${conversation.response}"

      Based on all this information, write a natural, friendly, and engaging follow-up message.
      - Keep it concise (2-3 sentences).
      - Ask an open-ended question related to their profile or your shared interests to encourage a reply.
      - DO NOT sound like a robot or use overly formal language.
      - DO NOT repeat what was already said. Continue the conversation.

      Generate ONLY the message text.
    `;

    try {
        // FIX: Updated model from prohibited 'gemini-1.5-flash' to 'gemini-2.5-flash' per coding guidelines.
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        if (response && response.text) {
            return response.text.trim();
        } else {
            throw new Error("Gemini API returned an empty response.");
        }
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to generate suggestion from Gemini API.");
    }
}
