
import React, { useState } from 'react';
import { View } from './types';
import DashboardView from './components/DashboardView';
import HandoffView from './components/HandoffView';
import ConfigurationView from './components/ConfigurationView';
import { DashboardIcon, ChatIcon, SettingsIcon, LogoIcon } from './components/icons/Icons';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.Dashboard);

  const renderView = () => {
    switch (activeView) {
      case View.Handoffs:
        return <HandoffView />;
      case View.Configuration:
        return <ConfigurationView />;
      case View.Dashboard:
      default:
        return <DashboardView />;
    }
  };

  const NavItem: React.FC<{
    view: View;
    icon: React.ReactNode;
    label: string;
  }> = ({ view, icon, label }) => (
    <li
      className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${
        activeView === view
          ? 'bg-brand-purple text-white'
          : 'text-dark-text-secondary hover:bg-dark-card hover:text-white'
      }`}
      onClick={() => setActiveView(view)}
    >
      {icon}
      <span className="ml-3 text-lg">{label}</span>
    </li>
  );

  return (
    <div className="flex h-screen bg-dark-bg text-dark-text font-sans">
      <aside className="w-64 bg-dark-card border-r border-dark-border p-5 flex flex-col">
        <div className="flex items-center mb-10">
          <LogoIcon className="h-10 w-10 text-brand-light" />
          <h1 className="text-2xl font-bold ml-2 text-white">Quimera</h1>
        </div>
        <nav>
          <ul className="space-y-4">
            <NavItem view={View.Dashboard} icon={<DashboardIcon className="h-6 w-6" />} label="Dashboard" />
            <NavItem view={View.Handoffs} icon={<ChatIcon className="h-6 w-6" />} label="Handoffs" />
            <NavItem view={View.Configuration} icon={<SettingsIcon className="h-6 w-6" />} label="Configuration" />
          </ul>
        </nav>
        <div className="mt-auto text-center text-dark-text-secondary text-sm">
          <p>&copy; 2024 Quimera Project</p>
          <p>Version 1.0.0</p>
        </div>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">
        {renderView()}
      </main>
    </div>
  );
};

export default App;
