
export enum View {
  Dashboard = 'DASHBOARD',
  Handoffs = 'HANDOFFS',
  Configuration = 'CONFIGURATION',
}

export interface Metric {
  label: string;
  value: string;
  change?: string;
  changeType?: 'increase' | 'decrease';
}

export interface Handoff {
  id: string;
  profile: Profile;
  lastMessage: string;
  timestamp: string;
  interestScore: number;
}

export interface Profile {
  id: string;
  name: string;
  username: string;
  avatarUrl: string;
  age: number;
  bio: string;
  interests: string[];
  personality: string[];
  location: string;
  scores: {
    interesting: number;
    attractive: number;
    single: number;
    final: number;
  };
}

export interface Conversation {
    initialMessage: string;
    response: string;
}
