
import { Profile, DashboardMetrics, RecentActivity, ActivityType, ProfileScoreDistribution } from '../types';

const profiles: Profile[] = [
  {
    id: 1,
    username: 'ana.silva',
    name: 'Ana Silva',
    bio: 'Fotógrafa e amante de viagens ✈️ | Explorando o mundo um clique de cada vez. 🌍 | Café e bons livros.',
    avatarUrl: 'https://picsum.photos/seed/ana/200',
    stats: { posts: 150, followers: 2500, following: 500 },
    interests: ['fotografia', 'viagem', 'literatura', 'natureza', 'arte'],
    bigFive: { openness: 90, conscientiousness: 75, extraversion: 80, agreeableness: 85, neuroticism: 30 },
    finalScore: 92.5,
    collectedDate: '2025-10-10T10:00:00Z',
    analyzedDate: '2025-10-10T14:30:00Z',
  },
  {
    id: 2,
    username: 'bruno_costa',
    name: 'Bruno Costa',
    bio: 'Desenvolvedor de Software e entusiasta de tecnologia. 💻 | Gamer nas horas vagas. 🎮 | Viciado em trilhas e montanhismo. ⛰️',
    avatarUrl: 'https://picsum.photos/seed/bruno/200',
    stats: { posts: 85, followers: 1200, following: 300 },
    interests: ['tecnologia', 'games', 'trilhas', 'programação', 'cinema'],
    bigFive: { openness: 85, conscientiousness: 88, extraversion: 60, agreeableness: 70, neuroticism: 40 },
    finalScore: 85.0,
    collectedDate: '2025-10-11T11:00:00Z',
    analyzedDate: '2025-10-11T15:00:00Z',
  },
  {
    id: 3,
    username: 'carla_ferreira',
    name: 'Carla Ferreira',
    bio: 'Chef de cozinha e foodie. 🍲 | Compartilhando receitas e dicas gastronômicas. | Vinho e boa companhia.',
    avatarUrl: 'https://picsum.photos/seed/carla/200',
    stats: { posts: 320, followers: 15000, following: 800 },
    interests: ['gastronomia', 'vinho', 'restaurantes', 'culinária', 'viagens'],
    bigFive: { openness: 78, conscientiousness: 82, extraversion: 88, agreeableness: 75, neuroticism: 25 },
    finalScore: 78.2,
    collectedDate: '2025-10-12T09:00:00Z',
    analyzedDate: '2025-10-12T13:00:00Z',
  },
   {
    id: 4,
    username: 'daniel_almeida',
    name: 'Daniel Almeida',
    bio: 'Músico e produtor. 🎸 | Rock and roll na veia. | Gatos, café e filosofia.',
    avatarUrl: 'https://picsum.photos/seed/daniel/200',
    stats: { posts: 210, followers: 8000, following: 450 },
    interests: ['música', 'rock', 'gatos', 'filosofia', 'shows'],
    bigFive: { openness: 95, conscientiousness: 60, extraversion: 70, agreeableness: 65, neuroticism: 55 },
    finalScore: 72.8,
    collectedDate: '2025-10-12T14:00:00Z',
    analyzedDate: '2025-10-12T18:00:00Z',
  },
   {
    id: 5,
    username: 'elisa_rodrigues',
    name: 'Elisa Rodrigues',
    bio: 'Estudante de arquitetura e design. 🏛️ | Apaixonada por formas, cores e espaços.',
    avatarUrl: 'https://picsum.photos/seed/elisa/200',
    stats: { posts: 50, followers: 950, following: 600 },
    interests: ['arquitetura', 'design', 'arte moderna', 'urbanismo'],
    bigFive: { openness: 88, conscientiousness: 90, extraversion: 65, agreeableness: 80, neuroticism: 35 },
    finalScore: 68.5,
    collectedDate: '2025-10-13T08:00:00Z',
    analyzedDate: '2025-10-13T12:00:00Z',
  },
  {
    id: 6,
    username: 'felipe_santos',
    name: 'Felipe Santos',
    bio: 'Personal trainer. 💪 | Ajudando pessoas a alcançarem seus objetivos. | Vida saudável e musculação.',
    avatarUrl: 'https://picsum.photos/seed/felipe/200',
    stats: { posts: 400, followers: 25000, following: 150 },
    interests: ['fitness', 'musculação', 'nutrição', 'esportes'],
    bigFive: { openness: 60, conscientiousness: 92, extraversion: 85, agreeableness: 70, neuroticism: 20 },
    finalScore: 55.3,
    collectedDate: '2025-10-13T10:00:00Z',
    analyzedDate: '2025-10-13T16:00:00Z',
  }
];

const dashboardMetrics: DashboardMetrics = {
  totalProfiles: 1250,
  totalConversations: 340,
  totalHotspots: 25,
  responseRate: 42,
};

const recentActivities: RecentActivity[] = [
    { id: 1, type: ActivityType.PROFILE_ANALYZED, description: 'analisado com pontuação de 92.5', timestamp: 'há 5 minutos', profileId: 1, profileName: 'Ana Silva' },
    { id: 2, type: ActivityType.CONVERSATION_STARTED, description: 'iniciada com sucesso', timestamp: 'há 2 horas', profileId: 2, profileName: 'Bruno Costa' },
    { id: 3, type: ActivityType.HOTSPOT_CREATED, description: 'criado: "Viagem"', timestamp: 'há 5 horas' },
    { id: 4, type: ActivityType.NEW_PROFILE_COLLECTED, description: 'coletado do hotspot "Viagem"', timestamp: 'há 1 dia', profileId: 3, profileName: 'Carla Ferreira' },
];

const profileScoreDistribution: ProfileScoreDistribution[] = [
    { name: '0-20', count: 50 },
    { name: '21-40', count: 150 },
    { name: '41-60', count: 400 },
    { name: '61-80', count: 550 },
    { name: '81-100', count: 100 },
];

const api = {
  getProfiles: (): Promise<Profile[]> => {
    return new Promise(resolve => setTimeout(() => resolve(profiles), 500));
  },
  getProfileById: (id: number): Promise<Profile | undefined> => {
    const profile = profiles.find(p => p.id === id);
    return new Promise(resolve => setTimeout(() => resolve(profile), 300));
  },
  getDashboardData: (): Promise<{ metrics: DashboardMetrics; activities: RecentActivity[], distribution: ProfileScoreDistribution[] }> => {
    return new Promise(resolve => setTimeout(() => resolve({ metrics: dashboardMetrics, activities: recentActivities, distribution: profileScoreDistribution }), 400));
  },
};

export default api;
