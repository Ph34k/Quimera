
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, MessageSquare, Flame, Settings, LogOut, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

const Sidebar: React.FC = () => {
    const [isCollapsed, setIsCollapsed] = useState(false);

    const NavItem: React.FC<{ to: string; icon: React.ReactNode; text: string }> = ({ to, icon, text }) => (
        <NavLink
            to={to}
            className={({ isActive }) =>
                `flex items-center p-3 my-1 rounded-lg transition-colors duration-200 ${
                isActive
                    ? 'bg-sky-500 text-white shadow-md'
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                }`
            }
        >
            {icon}
            {!isCollapsed && <span className="ml-4 font-medium">{text}</span>}
        </NavLink>
    );

    return (
        <div className={`relative flex flex-col bg-slate-800 text-white transition-all duration-300 ease-in-out ${isCollapsed ? 'w-20' : 'w-64'}`}>
            <div className="flex items-center justify-between p-4 border-b border-slate-700 h-16">
                 <Sparkles className={`text-sky-400 h-8 w-8 transition-transform duration-300 ${isCollapsed ? 'mx-auto' : ''}`} />
                {!isCollapsed && <h1 className="text-xl font-bold text-white">Quimera</h1>}
            </div>

            <button onClick={() => setIsCollapsed(!isCollapsed)} className="absolute -right-3 top-16 bg-slate-700 text-slate-300 hover:bg-sky-500 hover:text-white rounded-full p-1.5 focus:outline-none focus:ring-2 focus:ring-sky-500 z-10">
                {isCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </button>
            
            <nav className="flex-1 px-3 py-4 overflow-y-auto">
                <NavItem to="/" icon={<LayoutDashboard size={20} />} text="Dashboard" />
                <NavItem to="/profiles" icon={<Users size={20} />} text="Perfis" />
                <NavItem to="/conversations" icon={<MessageSquare size={20} />} text="Conversas" />
                <NavItem to="/hotspots" icon={<Flame size={20} />} text="Hotspots" />
                <NavItem to="/settings" icon={<Settings size={20} />} text="Configurações" />
            </nav>
            
            <div className="px-3 py-4 border-t border-slate-700">
                <a href="#/logout" className="flex items-center p-3 my-1 rounded-lg text-slate-400 hover:bg-red-500 hover:text-white transition-colors duration-200">
                    <LogOut size={20} />
                    {!isCollapsed && <span className="ml-4 font-medium">Sair</span>}
                </a>
            </div>
        </div>
    );
};

export default Sidebar;
