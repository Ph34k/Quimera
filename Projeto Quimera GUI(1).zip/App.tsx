
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Profiles from './pages/Profiles';
import ProfileDetail from './pages/ProfileDetail';
import { ToastProvider } from './hooks/useToast';
import ToastContainer from './components/ToastContainer';

const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
    <div className="flex items-center justify-center h-full">
        <h1 className="text-4xl font-bold text-slate-500">{title}</h1>
    </div>
);

const App: React.FC = () => {
  return (
    <ToastProvider>
      <HashRouter>
        <div className="flex h-screen bg-slate-900 text-slate-300 font-sans">
          <Sidebar />
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/profiles" element={<Profiles />} />
              <Route path="/profiles/:id" element={<ProfileDetail />} />
              <Route path="/conversations" element={<PlaceholderPage title="Conversas" />} />
              <Route path="/hotspots" element={<PlaceholderPage title="Hotspots" />} />
              <Route path="/settings" element={<PlaceholderPage title="Configurações" />} />
            </Routes>
          </main>
        </div>
        <ToastContainer />
      </HashRouter>
    </ToastProvider>
  );
};

export default App;
