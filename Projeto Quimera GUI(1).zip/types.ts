
export interface BigFive {
  openness: number;
  conscientiousness: number;
  extraversion: number;
  agreeableness: number;
  neuroticism: number;
}

export interface ProfileStats {
  posts: number;
  followers: number;
  following: number;
}

export interface Profile {
  id: number;
  username: string;
  name: string;
  bio: string;
  avatarUrl: string;
  stats: ProfileStats;
  interests: string[];
  bigFive: BigFive;
  finalScore: number;
  collectedDate: string;
  analyzedDate: string;
}

export interface DashboardMetrics {
  totalProfiles: number;
  totalConversations: number;
  totalHotspots: number;
  responseRate: number;
}

export enum ActivityType {
  PROFILE_ANALYZED = 'PROFILE_ANALYZED',
  CONVERSATION_STARTED = 'CONVERSATION_STARTED',
  HOTSPOT_CREATED = 'HOTSPOT_CREATED',
  NEW_PROFILE_COLLECTED = 'NEW_PROFILE_COLLECTED'
}

export interface RecentActivity {
  id: number;
  type: ActivityType;
  description: string;
  timestamp: string;
  profileId?: number;
  profileName?: string;
}

export interface ProfileScoreDistribution {
  name: string;
  count: number;
}
