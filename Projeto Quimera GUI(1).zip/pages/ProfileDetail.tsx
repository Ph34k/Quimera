
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MessageCircle, RefreshCw, Trash2, Calendar, CheckCircle } from 'lucide-react';
import { Profile, BigFive } from '../types';
import api from '../services/api';

const StatItem: React.FC<{ value: number; label: string }> = ({ value, label }) => (
    <div className="text-center">
        <p className="text-xl font-bold text-white">{value.toLocaleString()}</p>
        <p className="text-sm text-slate-400">{label}</p>
    </div>
);

const InterestTag: React.FC<{ interest: string }> = ({ interest }) => {
    const colors = ['bg-sky-500/20 text-sky-300', 'bg-emerald-500/20 text-emerald-300', 'bg-amber-500/20 text-amber-300', 'bg-indigo-500/20 text-indigo-300', 'bg-pink-500/20 text-pink-300'];
    const color = colors[interest.length % colors.length];
    return (
        <span className={`px-3 py-1 text-sm font-medium rounded-full ${color}`}>
            {interest}
        </span>
    );
};

const BigFiveBar: React.FC<{ label: string; value: number }> = ({ label, value }) => (
    <div>
        <div className="flex justify-between mb-1">
            <span className="text-sm font-medium text-slate-300">{label}</span>
            <span className="text-sm font-medium text-slate-400">{value}%</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div className="bg-sky-500 h-2.5 rounded-full" style={{ width: `${value}%` }}></div>
        </div>
    </div>
);

const ScoreCard: React.FC<{ score: number }> = ({ score }) => {
    const getScoreStyle = () => {
        if (score > 80) return { bg: 'bg-green-500', shadow: 'shadow-green-500/40', text: 'text-green-500' };
        if (score > 60) return { bg: 'bg-yellow-500', shadow: 'shadow-yellow-500/40', text: 'text-yellow-500' };
        return { bg: 'bg-red-500', shadow: 'shadow-red-500/40', text: 'text-red-500' };
    };
    const style = getScoreStyle();
    return (
        <div className={`bg-slate-800 p-6 rounded-lg shadow-lg border-t-4 ${style.bg.replace('bg-','border-')}`}>
             <p className="text-sm font-semibold text-slate-400 mb-2">Pontuação Final</p>
             <p className={`text-5xl font-bold text-white text-center py-4 ${style.text}`}>{score.toFixed(1)}</p>
        </div>
    );
};

const ProfileDetail: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [profile, setProfile] = useState<Profile | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProfile = async () => {
            if (id) {
                setLoading(true);
                const data = await api.getProfileById(parseInt(id, 10));
                setProfile(data || null);
                setLoading(false);
            }
        };
        fetchProfile();
    }, [id]);

    if (loading) {
        return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-sky-500"></div></div>;
    }

    if (!profile) {
        return <div className="text-center text-slate-400">Perfil não encontrado.</div>;
    }
    
    const bigFiveLabels: { key: keyof BigFive, label: string }[] = [
        { key: 'openness', label: 'Abertura' },
        { key: 'conscientiousness', label: 'Conscienciosidade' },
        { key: 'extraversion', label: 'Extroversão' },
        { key: 'agreeableness', label: 'Amabilidade' },
        { key: 'neuroticism', label: 'Neuroticismo' },
    ];

    return (
        <div className="space-y-6">
            <div>
                <button onClick={() => navigate(-1)} className="flex items-center text-slate-400 hover:text-white mb-4">
                    <ArrowLeft size={20} className="mr-2" />
                    Voltar
                </button>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Content */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-slate-800 p-6 rounded-lg shadow-lg">
                        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                            <img src={profile.avatarUrl} alt={profile.name} className="h-32 w-32 rounded-full object-cover ring-4 ring-slate-700"/>
                            <div className="text-center sm:text-left">
                                <h1 className="text-3xl font-bold text-white">{profile.name}</h1>
                                <p className="text-lg text-sky-400">@{profile.username}</p>
                                <p className="text-slate-400 mt-2 max-w-md">{profile.bio}</p>
                            </div>
                        </div>
                        <div className="mt-6 flex justify-around border-t border-slate-700 pt-4">
                            <StatItem value={profile.stats.posts}