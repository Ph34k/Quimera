
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Profile } from '../types';
import api from '../services/api';

const ScoreBadge: React.FC<{ score: number }> = ({ score }) => {
    const getScoreColor = () => {
        if (score > 80) return 'bg-green-500/20 text-green-400 border-green-500/30';
        if (score > 60) return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
        return 'bg-red-500/20 text-red-400 border-red-500/30';
    };
    return (
        <span className={`px-2.5 py-1 text-sm font-semibold rounded-full border ${getScoreColor()}`}>
            {score.toFixed(1)}
        </span>
    );
};


const Profiles: React.FC = () => {
    const [profiles, setProfiles] = useState<Profile[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProfiles = async () => {
            setLoading(true);
            const data = await api.getProfiles();
            setProfiles(data);
            setLoading(false);
        };
        fetchProfiles();
    }, []);

    if (loading) {
        return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-sky-500"></div></div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-white">Perfis</h1>
                <button className="bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                    Coletar Novos Perfis
                </button>
            </div>
            
            <div className="bg-slate-800 rounded-lg shadow-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-slate-700/50">
                            <tr>
                                <th className="p-4 font-semibold">Perfil</th>
                                <th className="p-4 font-semibold hidden md:table-cell">Nome Completo</th>
                                <th className="p-4 font-semibold">Pontuação Final</th>
                                <th className="p-4 font-semibold">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            {profiles.map(profile => (
                                <tr key={profile.id} className="border-b border-slate-700 hover:bg-slate-700/50 transition-colors">
                                    <td className="p-4 flex items-center space-x-3">
                                        <img src={profile.avatarUrl} alt={profile.name} className="h-10 w-10 rounded-full object-cover" />
                                        <div>
                                            <p className="font-semibold text-white">{profile.username}</p>
                                            <p className="text-sm text-slate-400 md:hidden">{profile.name}</p>
                                        </div>
                                    </td>
                                    <td className="p-4 hidden md:table-cell">{profile.name}</td>
                                    <td className="p-4">
                                        <ScoreBadge score={profile.finalScore} />
                                    </td>
                                    <td className="p-4">
                                        <Link to={`/profiles/${profile.id}`} className="flex items-center text-sky-400 hover:text-sky-300 font-semibold text-sm">
                                            Ver detalhes <ArrowRight size={16} className="ml-1" />
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Profiles;
