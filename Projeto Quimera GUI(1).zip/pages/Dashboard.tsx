
import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Users, MessageSquare, Flame, Percent, Activity, FileCheck, MessageCircle, UserPlus, Link2 } from 'lucide-react';
import { DashboardMetrics, RecentActivity, ActivityType, ProfileScoreDistribution } from '../types';
import api from '../services/api';

const MetricCard: React.FC<{ icon: React.ReactNode; title: string; value: string; color: string }> = ({ icon, title, value, color }) => (
    <div className="bg-slate-800 p-6 rounded-lg shadow-lg flex items-center space-x-4">
        <div className={`p-3 rounded-full ${color}`}>
            {icon}
        </div>
        <div>
            <p className="text-slate-400 text-sm font-medium">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
        </div>
    </div>
);

const ActivityIcon: React.FC<{ type: ActivityType }> = ({ type }) => {
    const icons = {
        [ActivityType.PROFILE_ANALYZED]: <FileCheck className="h-5 w-5 text-blue-400" />,
        [ActivityType.CONVERSATION_STARTED]: <MessageCircle className="h-5 w-5 text-green-400" />,
        [ActivityType.HOTSPOT_CREATED]: <Link2 className="h-5 w-5 text-purple-400" />,
        [ActivityType.NEW_PROFILE_COLLECTED]: <UserPlus className="h-5 w-5 text-yellow-400" />,
    };
    return icons[type] || <Activity className="h-5 w-5 text-slate-400" />;
};

const Dashboard: React.FC = () => {
    const [data, setData] = useState<{ metrics: DashboardMetrics; activities: RecentActivity[]; distribution: ProfileScoreDistribution[] } | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const dashboardData = await api.getDashboardData();
            setData(dashboardData);
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading || !data) {
        return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-sky-500"></div></div>;
    }

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard icon={<Users size={24} className="text-white"/>} title="Total de Perfis" value={data.metrics.totalProfiles.toLocaleString()} color="bg-blue-500" />
                <MetricCard icon={<MessageSquare size={24} className="text-white"/>} title="Conversas Ativas" value={data.metrics.totalConversations.toLocaleString()} color="bg-green-500" />
                <MetricCard icon={<Flame size={24} className="text-white"/>} title="Hotspots Ativos" value={data.metrics.totalHotspots.toLocaleString()} color="bg-purple-500" />
                <MetricCard icon={<Percent size={24} className="text-white"/>} title="Taxa de Resposta" value={`${data.metrics.responseRate}%`} color="bg-yellow-500" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-slate-800 p-6 rounded-lg shadow-lg">
                    <h2 className="text-xl font-semibold text-white mb-4">Distribuição de Perfis por Pontuação</h2>
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <BarChart data={data.distribution} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                <XAxis dataKey="name" stroke="#94a3b8" />
                                <YAxis stroke="#94a3b8" />
                                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                                <Legend />
                                <Bar dataKey="count" name="Perfis" fill="#0ea5e9" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-slate-800 p-6 rounded-lg shadow-lg">
                    <h2 className="text-xl font-semibold text-white mb-4">Atividades Recentes</h2>
                    <ul className="space-y-4">
                        {data.activities.map(activity => (
                            <li key={activity.id} className="flex items-start space-x-3">
                                <div className="flex-shrink-0 pt-1">
                                    <ActivityIcon type={activity.type} />
                                </div>
                                <div>
                                    <p className="text-sm text-slate-300">
                                        {activity.profileName && <span className="font-semibold text-sky-400">{activity.profileName}</span>} {activity.description}
                                    </p>
                                    <p className="text-xs text-slate-500">{activity.timestamp}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
